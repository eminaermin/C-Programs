/*
 * Emina Ermin Sinanovic G01176900
 * CS 262, Lab Section 218
 * Lab 1
 */
#include <stdio.h>
#include <stdlib.h>

int main(){
	printf("Hello World!\n");
	printf("My name is Emina\n");
	return 0;
}
